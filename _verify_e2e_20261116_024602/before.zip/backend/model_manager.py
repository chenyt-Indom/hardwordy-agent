# -*- coding: utf-8 -*-
"""Ollama 模型下载管理：后台线程 + 实时进度 + 取消 + 删除

为什么不用现有的 /api/pull（阻塞式）
------------------------------------
一个 30B 模型十几 GB，下载要几十分钟。HTTP 请求一直挂着会：
  1. 浏览器 / 反向代理超时断开（实测 60 秒就断）
  2. 用户看不到任何进度，以为卡死
  3. 没法取消，只能杀进程
所以改成：**后台线程下载 + 前端轮询 /api/model/status**。

进度怎么算（关键）
------------------
Ollama 按 layer 分别上报，多个 layer 是**并行**下载的：
  {"status":"downloading","digest":"sha256:aaa","total":123,"completed":45}
  {"status":"downloading","digest":"sha256:bbb","total":999,"completed":100}
如果直接拿最后一条算，进度会在 3% 和 70% 之间乱跳。
必须**按 digest 把每个 layer 的最新值存下来，然后累加**。

取消怎么实现
------------
Ollama 的 pull 不支持"暂停"，只支持断开连接（已下载的 layer 会保留在
blobs 里，下次 pull 自动断点续传）。所以：
  · 取消 = 设标志 → 下载线程在下一个 chunk 发现 → resp.close()
  · 界面上"暂停"和"取消"是同一个动作，文案上区分即可。
"""
from __future__ import annotations

import json
import threading
import time
from typing import Any

import requests
import logging
logger = logging.getLogger(__name__)

# Ollama 地址**走配置**，别写死 —— 换端口 / 换机器（远程 Ollama）时要能跟着走。
# 之前写死 127.0.0.1:11434，配置改了这里不生效。
_DEF = "http://127.0.0.1:11434"
# 本机地址一律不走系统代理：开发机上常挂着 http_proxy（抓包/科学上网），
# requests 会老实把 127.0.0.1 也发给代理，结果拿到 502 而不是连 Ollama。
_NO_PROXY = {"http": None, "https": None}
# (连接超时, 读取超时)：大文件下载读取给足 1 小时
TIMEOUT = (10, 3600)


def _base() -> str:
    try:
        from . import config
        return str((config.load_config() or {}).get("ollama_url") or _DEF).rstrip("/")
    except Exception:
        return _DEF

_LOCK = threading.Lock()

# 全局状态（单实例：同一时刻只允许一个下载任务）
_STATE: dict[str, Any] = {
    "model": "",
    "status": "idle",      # idle | pulling | verifying | done | error | cancelled
    "percent": 0.0,
    "completed": 0,
    "total": 0,
    "speed": 0.0,          # bytes/s
    "eta": 0,              # 剩余秒数
    "error": "",
    "cancel": False,
    "started_at": 0.0,
    "finished_at": 0.0,
}

_thread: threading.Thread | None = None


def _reset(model: str) -> None:
    with _LOCK:
        _STATE.update({
            "model": model, "status": "pulling", "percent": 0.0,
            "completed": 0, "total": 0, "speed": 0.0, "eta": 0,
            "error": "", "cancel": False,
            "started_at": time.time(), "finished_at": 0.0,
        })


def get_state() -> dict[str, Any]:
    with _LOCK:
        return dict(_STATE)


def is_running() -> bool:
    with _LOCK:
        return _STATE["status"] in ("pulling", "verifying")


def cancel() -> bool:
    """请求取消。下载线程会在下一个 chunk 主动断开（已下载部分保留）。"""
    with _LOCK:
        if _STATE["status"] not in ("pulling", "verifying"):
            return False
        _STATE["cancel"] = True
        return True


def pull(model: str) -> dict[str, Any]:
    """启动后台下载。已有任务在跑就直接返回当前状态。"""
    global _thread
    if is_running():
        return {"ok": False, "msg": "已有下载任务在进行", "state": get_state()}
    _reset(model)
    _thread = threading.Thread(target=_worker, args=(model,), daemon=True)
    _thread.start()
    return {"ok": True, "msg": f"已开始下载 {model}", "state": get_state()}


def _worker(model: str) -> None:
    layers: dict[str, tuple[int, int]] = {}
    last_t = time.time()
    last_c = 0
    try:
        resp = requests.post(
            f"{_base()}/api/pull",
            json={"name": model, "stream": True},
            stream=True, timeout=TIMEOUT, proxies=_NO_PROXY)
        if resp.status_code != 200:
            raise RuntimeError(
                f"Ollama 返回 {resp.status_code}: {resp.text[:200]}")

        for raw in resp.iter_lines(decode_unicode=True):
            if not raw:
                continue
            # 每个 chunk 都检查一次取消
            with _LOCK:
                if _STATE["cancel"]:
                    try:
                        resp.close()
                    except Exception:
                        logger.debug("silent-except", exc_info=True)
                    _STATE["status"] = "cancelled"
                    _STATE["finished_at"] = time.time()
                    return
            try:
                obj = json.loads(raw)
            except json.JSONDecodeError:
                continue

            st = str(obj.get("status") or "")

            if obj.get("error"):
                raise RuntimeError(str(obj["error"]))

            # ⚠️⚠️ 关键修正（2026-11-08 实测）：
            # Ollama 的下载状态是 `"pulling <digest前缀>"`，**不是** `"downloading"`：
            #   {"status":"pulling c5396e06af29","digest":"sha256:...",
            #    "total":397807936,"completed":82393231}
            # 之前按 st == "downloading" 判断，一条都命中不了，进度永远 0%。
            # 改成「有 total + 有 digest」即视为下载中 —— 这个判据更稳，
            # 因为 Ollama 换文案（pulling / downloading / fetching）都不影响。
            if obj.get("total") and obj.get("digest"):
                d = obj.get("digest") or "?"
                layers[d] = (int(obj.get("total") or 0),
                             int(obj.get("completed") or 0))
                total = sum(t for t, _ in layers.values())
                done = sum(c for _, c in layers.values())
                now = time.time()
                dt = max(0.001, now - last_t)
                speed = max(0.0, (done - last_c) / dt)
                last_t, last_c = now, done
                eta = int((total - done) / speed) if speed > 0 and total > done else 0
                with _LOCK:
                    _STATE.update({
                        "percent": round(done / total * 100, 1) if total else 0.0,
                        "completed": done,
                        "total": total,
                        "speed": speed,
                        "eta": eta,
                        "status": "pulling",
                    })
            elif st == "pulling manifest":
                # 拉清单阶段：还没开始传数据，保持 pulling 但进度不动
                with _LOCK:
                    _STATE["status"] = "pulling"
            elif st in ("verifying sha256 digest", "writing manifest",
                        "removing any unused layers"):
                with _LOCK:
                    _STATE["status"] = "verifying"
                    _STATE["percent"] = 99.0
            elif st == "success":
                with _LOCK:
                    _STATE.update({"status": "done", "percent": 100.0,
                                   "finished_at": time.time()})
                return

        # 流结束但没收到 success：按完成处理（Ollama 有时不发 success）
        with _LOCK:
            _STATE.update({"status": "done", "percent": 100.0,
                           "finished_at": time.time()})
    except requests.exceptions.ConnectionError:
        # ⚠️ 2026-11-11：连不上时不要甩一坨 "Max retries exceeded with url..."，
        #   用户看不懂也不知道下一步做什么。直接说清楚 + 给出动作。
        with _LOCK:
            _STATE.update({
                "status": "error",
                "error": "连不上 Ollama（%s）—— 下载本地模型必须先让它跑起来。\n"
                         "请先执行 ollama serve（或双击 Ollama 图标），"
                         "看到 11434 端口起来后再点一次下载。" % _base(),
                "finished_at": time.time()})
    except Exception as e:                        # noqa: BLE001
        with _LOCK:
            _STATE.update({"status": "error",
                           "error": str(e)[:300],
                           "finished_at": time.time()})


def unload_all() -> dict:
    """把**当前真的在显存里**的 Ollama 模型请出去，返回卸了哪些。

    场景（2026-11-11 用户提的）：顶栏从本地模型切到云端（DeepSeek）之后，
    本地模型一点用都没有，但 `model_keep_alive` 配的是 **4 小时** ——
    它会一直赖在显存里（8B 实测占 9GB），12GB 卡上等于把显卡锁死：
    别的程序（游戏 / 绘图 / 另一个模型）拿不到显存，用户体感就是「卡死」。

    为什么不直接复用 `t2i.free_ollama_vram()`：
      那个是给「画图前腾地方」写的，会往**配置里列的所有模型**发 keep_alive=0，
      包括根本没加载的。Ollama 收到这种请求会**先加载再卸载** ——
      一个 5.8GB 的模型白折腾十几秒，中途还会把显存占满一次。
      这里先查 /api/ps，只处理确实加载着的。

    ⚠️ keep_alive=0 是**异步**的（实测约 2 秒才真退出），
       必须轮询到 /api/ps 空为止，否则调用方以为腾出来了、其实还没有。
    """
    base = _base()
    out = {"ok": True, "before": [], "freed": [], "waited": 0.0, "error": ""}

    def _ps_names() -> list:
        r = requests.get(f"{base}/api/ps", timeout=(3, 10), proxies=_NO_PROXY)
        d = r.json()
        return [str(m.get("name") or "") for m in (d.get("models") or [])
                if m.get("name")]

    try:
        before = _ps_names()
    except requests.exceptions.ConnectionError:
        return {"ok": False, "before": [], "freed": [], "waited": 0.0,
                "error": "连不上 Ollama（%s），没有可释放的显存" % base}
    except Exception as e:                        # noqa: BLE001
        return {"ok": False, "before": [], "freed": [], "waited": 0.0,
                "error": "%s: %s" % (type(e).__name__, e)}

    out["before"] = before
    if not before:
        return out                                # 本来就没加载，什么都不用做

    for m in before:
        try:
            requests.post(f"{base}/api/generate",
                          json={"model": m, "keep_alive": 0},
                          timeout=(5, 30), proxies=_NO_PROXY)
            out["freed"].append(m)
        except Exception:                         # noqa: BLE001
            logger.debug("silent-except", exc_info=True)                                  # 单个失败不影响其它的

    # 等它真的落地：最多 12 秒（和 t2i 那边同一套经验值）
    t0 = time.time()
    left = before
    for _ in range(24):
        try:
            left = _ps_names()
        except Exception:                         # noqa: BLE001
            left = []
            break
        if not left:
            break
        time.sleep(0.5)
    out["waited"] = round(time.time() - t0, 1)

    # ⚠️ 2026-11-11 实测：模型 runner 一旦卡死，Ollama 会**收下** keep_alive=0
    #   （expires_at 立刻变成过去时间）但显存就是不放 —— 实测卡了 10.4GB 十几分钟，
    #   `nvidia-smi` 里 llama-server.exe 一直挂着，任何 API 都卸不掉，只能重启 Ollama。
    #   所以这里必须**复查**：还在就是失败，别报 ok 让调用方误以为腾出来了。
    if left:
        out["ok"] = False
        out["stuck"] = left
        out["error"] = (
            "Ollama 收下了卸载请求，但显存没放出来（%s）。"
            "这通常是模型进程卡死了 —— 退出 Ollama（右下角托盘 → Quit）再重新打开即可。"
            % "、".join(left))
    return out


def remove(model: str) -> dict[str, Any]:
    """删除已下载的模型（释放磁盘）。"""
    if is_running() and get_state().get("model") == model:
        return {"ok": False, "msg": "该模型正在下载，先取消再删除"}
    try:
        r = requests.delete(f"{_base()}/api/delete",
                            json={"name": model}, timeout=(8, 120),
                            proxies=_NO_PROXY)
        if r.status_code != 200:
            return {"ok": False, "msg": f"HTTP {r.status_code}: {r.text[:200]}"}
        return {"ok": True, "msg": f"已删除 {model}"}
    except requests.RequestException as e:
        return {"ok": False, "msg": f"连接 Ollama 失败：{e}"}


def installed() -> list[dict]:
    """已安装模型清单（含体积）。"""
    try:
        r = requests.get(f"{_base()}/api/tags", timeout=(6, 20),
                         proxies=_NO_PROXY)
        d = r.json()
        out = []
        for m in (d.get("models") or []):
            out.append({
                "name": m.get("name", ""),
                "size": int(m.get("size") or 0),
                "modified_at": m.get("modified_at", ""),
            })
        return out
    except Exception:
        return []
