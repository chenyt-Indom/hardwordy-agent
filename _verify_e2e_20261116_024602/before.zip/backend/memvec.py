# -*- coding: utf-8 -*-
"""记忆库的**条目级**向量索引（长期 / 短期 / 历史会话）。

为什么要这一层
--------------
原来的 `memory.search_all` 是「整块正文比一次、整块正文吐回去」：
长期记忆上限 15000 字、现在 67 条，查询命中一条就把**全部**返回 ——
既塞满 context，又定位不到具体是哪一条。而且它只做 2-gram 交集，
换个说法（「我叫什么」vs「用户姓名：陈宇桐」）就完全召回不到。

这里的做法
----------
· **记忆拆成条目**（按 `；` / 换行切），一条一个向量；
· **混合打分**：语义向量（主）+ 关键词覆盖（兜底），
  语义分或覆盖率**任一达标就收**，两个都不过就不返回（宁缺毋滥）；
· **增量更新**：按条目内容 hash 复用旧向量，只给新增/改动的条目算；
  记忆一写入就自动同步（后台线程，不阻塞工具调用）；
· **转录不进大索引**：实测本机 233 个 .jsonl / 19.6MB，全量索引要 4 分钟、
  索引矩阵几十 MB。改成「关键词预筛 → 向量重排」：先按字面挑出候选，
  只给这十几条算向量。延迟 0.1 秒级，而且永远是最新的。

关键词覆盖为什么不用 2-gram
---------------------------
实测踩过：查询「我在哪个学校读书」，记忆里那条「学校：广州民航职业技术学院…」
的 2-gram 交集只有 {学校}，覆盖率 0.14（门槛 0.5），而它的语义分 0.381
（门槛 0.42）—— 两个信号同时不过，**明明相关的条目就是召回不到**。
原因是 2-gram 会被断词切碎（「哪个学」「校读书」都匹配不上「学校」）。
所以改用**字级覆盖**（去掉虚词后看查询的字有多少在条目里），
同一条查询覆盖率是 2/4=0.5，正常召回。
"""
import os
import json
import time
import hashlib
import threading
import logging

import numpy as np

from . import embed
from . import memory
logger = logging.getLogger(__name__)

_LOG = logging.getLogger("uvicorn.error")

VEC_FILE = os.path.join(memory.MEM_DIR, "_vec.npy")
META_FILE = os.path.join(memory.MEM_DIR, "_vec_meta.json")

# 门槛：按实测校准（bge-small-zh：相关条目 vec 约 0.45~0.78，无关约 0.15~0.35）
# 实测对比（12 条已知答案的查询 + 6 条无关查询）：
#   0.42 → top3 12/12，无关查询误召 2/6
#   0.46 → top3 12/12，无关查询误召 1/6   ← 取这个
#   0.50 → top3 11/12（开始漏），误召 1/6
MIN_VEC = 0.46
MIN_COV = 0.50
W_VEC, W_COV = 0.75, 0.25        # 只用于排序，不参与拦截

MAX_ITEMS = 4000                 # 记忆条目上限
# 转录：不进索引，只做预筛 + 重排
TRANS_PASSAGE = 600              # 一段对话最多多少字
TRANS_MAX = 2500                 # 最多收集多少段（按文件 mtime 从新到旧）
TRANS_PER_FILE = 400             # 单个文件最多取多少段（防止一个巨型测试会话吃掉全部名额）
TRANS_CANDIDATES = 8             # 预筛出来送去向量重排的候选数（实测 14 条要 400ms+）
TRANS_TOP = 2                    # 转录最多挤进结果几条

_lock = threading.RLock()
_idx = {"sig": "", "dsig": "", "items": [], "mat": None}
_trans = {"sig": "", "items": []}
_dirty = True
_syncing = False

# 虚词字：算字级覆盖率时先剔掉，否则「我」「的」「是」这种会白送覆盖率
_STOP_CHARS = set(
    "的了是在和与我你他她它吧呢啊吗么什怎哪谁几这那个有也都就还很会要能可"
    "请帮下换或并及想说对把被从到给让用做去来样些时候您咱其之而已")
_PUNCT = set("，。、；：？！…—·「」『』（）《》〈〉,.!?;:\"'()[]{}<>~`@#$%^&*_-+=/\\| \t\n\r")


# =====================================================================
#  打分工具
# =====================================================================
def _text_sets(text: str):
    """把文本变成 (实字集合, 2-gram 集合)。转录条目在构建时预算好，查询时不再分词。"""
    t = text or ""
    chars = {c for c in t
             if c not in _STOP_CHARS and c not in _PUNCT and not c.isspace()}
    return chars, set(memory._tokenize(t))


def _q_sets(query: str):
    return _text_sets(query)


def _cov_pair(qchars, qtoks, tchars, ttoks):
    """返回 (字级覆盖, 2-gram 覆盖)。

    门槛用两者**较大值**（只要一种说得通就收）——
    实测：查「我在哪个学校读书」，2-gram 只命中 {学校}（0.14），
    但字级是 2/4=0.5，靠字级才召回得到「学校：广州民航职业技术学院…」。
    排序用加权（2-gram 更能分出「后端」与「前端」这类近义边界）。
    """
    c = (len(qchars & tchars) / float(len(qchars))) if qchars else 0.0
    b = (len(qtoks & ttoks) / float(len(qtoks))) if qtoks else 0.0
    return c, b


# =====================================================================
#  条目收集（长期 + 短期）
# =====================================================================
def _mk(level, sid, section, text, source="auto"):
    key = hashlib.md5(
        ("%s|%s|%s" % (level, sid, text)).encode("utf-8")).hexdigest()[:16]
    return {"key": key, "level": level, "sid": sid or "",
            "section": section or "", "text": text, "source": source}


def _push(items, level, sid, section, text, source="auto"):
    t = memory._norm_point(text)
    if len(t) < 2:
        return
    items.append(_mk(level, sid, section, t, source))


def _collect_items():
    items = []
    for t in memory._split_items(memory.get_long()):
        _push(items, "长期记忆", "", "所有对话共享", t)
    try:
        shorts = memory._load_shorts()
    except Exception:
        shorts = {}
    for sid, obj in (shorts or {}).items():
        body = str((obj or {}).get("content") or "")
        for t in memory._split_items(body):
            _push(items, "短期记忆", sid, sid, t)
    if len(items) > MAX_ITEMS:
        items = items[-MAX_ITEMS:]     # 超限时保留靠后的（新条目更重要）
    return items


def _data_sig():
    parts = []
    for p in (memory.LONG_FILE, memory.SHORT_FILE):
        try:
            parts.append("%d:%d" % (os.path.getsize(p), int(os.path.getmtime(p))))
        except Exception:
            parts.append("0")
    d = memory.TRANSCRIPT_DIR
    n, sz, mt = 0, 0, 0
    if os.path.isdir(d):
        try:
            for fn in os.listdir(d):
                if not fn.endswith(".jsonl"):
                    continue
                st = os.stat(os.path.join(d, fn))
                n += 1
                sz += st.st_size
                mt = max(mt, int(st.st_mtime))
        except Exception:
            logger.debug("silent-except", exc_info=True)
    parts.append("t:%d:%d:%d" % (n, sz, mt))
    return "|".join(parts)


# =====================================================================
#  索引构建（增量）
# =====================================================================
def _load_disk():
    try:
        if not (os.path.isfile(VEC_FILE) and os.path.isfile(META_FILE)):
            return None
        with open(META_FILE, "r", encoding="utf-8") as f:
            meta = json.load(f)
        arr = np.load(VEC_FILE)
        keys = list(meta.get("keys") or [])
        if arr.ndim != 2 or arr.shape[0] != len(keys):
            return None
        return {"sig": meta.get("sig") or "",
                "vecs": {k: arr[i] for i, k in enumerate(keys)}}
    except Exception:
        return None


def _save_disk(sig, items, mat):
    try:
        os.makedirs(memory.MEM_DIR, exist_ok=True)
        if mat is None or not items:
            for p in (VEC_FILE, META_FILE):
                if os.path.isfile(p):
                    os.remove(p)
            return
        tmp = VEC_FILE + ".tmp.npy"
        np.save(tmp, mat)
        os.replace(tmp, VEC_FILE)
        meta = {"sig": sig, "updated_at": time.time(),
                "keys": [it["key"] for it in items],
                "items": [{"level": it["level"], "sid": it["sid"],
                           "text": it["text"][:200]} for it in items]}
        tmp2 = META_FILE + ".tmp"
        with open(tmp2, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False)
        os.replace(tmp2, META_FILE)
    except Exception as e:
        _LOG.warning("记忆索引落盘失败：%s", e)


def sync(force: bool = False):
    """把记忆条目索引同步到最新（增量：只算新增/改动的条目）。"""
    global _dirty
    with _lock:
        dsig = _data_sig()
        sig = embed.signature()
        if (not force and _idx["mat"] is not None
                and _idx["sig"] == sig and _idx.get("dsig") == dsig):
            return _idx

        items = _collect_items()
        keys = [it["key"] for it in items]

        cache = {}
        disk = _load_disk()
        if disk and disk["sig"] == sig:
            cache = disk["vecs"]

        missing = [it for it in items if it["key"] not in cache]
        if missing and sig != "none":
            vecs = embed.embed_texts([it["text"] for it in missing])
            if vecs is not None:
                for it, v in zip(missing, vecs):
                    cache[it["key"]] = np.asarray(v, dtype=np.float32)
            else:
                _LOG.warning("记忆向量化失败，本轮退化为关键词检索")

        mat = None
        if keys and all(k in cache for k in keys):
            try:
                mat = np.stack([cache[k] for k in keys]).astype(np.float32)
            except Exception:
                mat = None

        _idx.update({"sig": sig, "dsig": dsig, "items": items, "mat": mat})
        _dirty = False
        _save_disk(sig, items, mat)
        return _idx


def _bg_sync():
    global _syncing
    try:
        time.sleep(0.25)          # 防抖：连续写入只同步一次
        sync()
    except Exception as e:
        _LOG.warning("记忆索引后台同步失败：%s", e)
    finally:
        with _lock:
            _syncing = False


def touch():
    """记忆被写入后调用：标记脏 + 后台增量同步（不阻塞调用方）。"""
    global _dirty, _syncing
    _dirty = True
    with _lock:
        if _syncing:
            return
        _syncing = True
    try:
        threading.Thread(target=_bg_sync, daemon=True).start()
    except Exception:
        with _lock:
            _syncing = False


# =====================================================================
#  历史会话：预筛 + 向量重排（不进大索引）
# =====================================================================
def _parse_trans_file(path: str, fn: str) -> list:
    """把一个 .jsonl 切成「一段对话」的条目列表。"""
    out = []
    buf, buf_len = [], 0

    def _flush():
        if not buf or len(out) >= TRANS_PER_FILE:
            return
        txt = "\n".join("%s：%s" % (r, c) for r, c in buf)[:TRANS_PASSAGE]
        ch, tk = _text_sets(txt)
        out.append({"key": "T:%s:%d" % (fn, len(out)),
                    "level": "历史会话", "sid": fn[:-6],
                    "section": fn[:-6], "text": txt, "source": "transcript",
                    "_chars": ch, "_tok": tk})

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    o = json.loads(line)
                except Exception:
                    continue
                role = o.get("role")
                if role == "sep":
                    _flush()
                    buf, buf_len = [], 0
                    continue
                if role not in ("user", "assistant"):
                    continue
                c = str(o.get("content") or "").strip()
                if not c:
                    continue
                buf.append(("用户" if role == "user" else "助手", c[:400]))
                buf_len += len(c)
                if buf_len >= TRANS_PASSAGE:
                    _flush()
                    buf, buf_len = [], 0
        _flush()
    except Exception as e:
        _LOG.warning("读转录失败（%s）：%s", fn, e)
    return out


def _trans_items():
    """把转录文件切成「一段对话」的候选，按文件新→旧收集，有上限。

    ⚠️ **按文件增量缓存**：转录每轮对话都会追加，如果每次都重扫全部 19.6MB，
    每次 search_memory 都要 1 秒。这里按 (mtime, size) 判断哪个文件变了，
    只重解析变了的那个，其余复用上次结果。
    """
    d = memory.TRANSCRIPT_DIR
    if not os.path.isdir(d):
        return []
    files = []
    for fn in os.listdir(d):
        if not fn.endswith(".jsonl"):
            continue
        p = os.path.join(d, fn)
        try:
            st = os.stat(p)
            files.append((st.st_mtime, fn, p, st.st_size))
        except Exception:
            logger.debug("silent-except", exc_info=True)
    files.sort(reverse=True)          # 新的优先

    with _lock:
        cache = dict(_trans.get("files") or {})

    new_cache, out = {}, []
    for mt, fn, path, size in files:
        if len(out) >= TRANS_MAX:
            break
        stamp = (int(mt), size)
        got = cache.get(fn)
        if got and got[0] == stamp:
            items = got[1]
        else:
            items = _parse_trans_file(path, fn)
        new_cache[fn] = (stamp, items)
        for it in items:
            if len(out) >= TRANS_MAX:
                break
            out.append(it)

    with _lock:
        _trans.update({"files": new_cache, "items": out})
    return out


def _search_transcripts(query: str, top_k: int = TRANS_TOP) -> list:
    """历史会话：先按字面预筛（便宜），再只给候选算向量（贵）。"""
    items = _trans_items()
    if not items:
        return []
    qc, qt = _q_sets(query)

    scored = []
    for it in items:
        c, b = _cov_pair(qc, qt, it.get("_chars") or set(), it.get("_tok") or set())
        cov = max(c, b)
        if cov >= MIN_COV:
            scored.append((cov, 0.6 * c + 0.4 * b, it))
    if not scored:
        return []
    scored.sort(key=lambda x: x[1], reverse=True)
    cand = scored[:TRANS_CANDIDATES]

    vecs, qv = None, None
    try:
        vecs = embed.embed_texts([it["text"] for _, _, it in cand])
        qv = embed.embed_texts([query], is_query=True)
        if vecs is None or qv is None:
            vecs = None
    except Exception:
        vecs = None

    out = []
    for i, (cov, rank_cov, it) in enumerate(cand):
        vec = 0.0
        if vecs is not None:
            vec = float(np.dot(vecs[i], qv[0]))
            # 门槛收紧：实测原来「语义 0.34 + 字面 0.80」也能过，
            # 结果查「挑餐厅」把一段系统提示词捞了出来。转录必须语义也像。
            if not (vec >= 0.45 or (vec >= 0.38 and cov >= 0.85)):
                continue
        score = (W_VEC * vec + W_COV * rank_cov) if vecs is not None else rank_cov
        body = it["text"]
        if len(body) > 300:
            body = body[:300] + " …（后续已截断）"
        out.append({"level": "历史会话", "section": it["section"],
                    "content": body, "source": "transcript",
                    "score": round(float(score), 4),
                    "vec": round(vec, 4), "cov": round(cov, 3)})
    out.sort(key=lambda x: x["score"], reverse=True)
    return out[:top_k]


# =====================================================================
#  检索
# =====================================================================
def _label(it, sid):
    lv = it["level"]
    if lv == "短期记忆":
        return "本对话短期" if (sid and it["sid"] == sid) else "其他对话短期"
    return lv


def search(query: str, sid: str = "", top_k: int = 5,
           min_vec: float = MIN_VEC, min_cov: float = MIN_COV,
           with_transcripts: bool = True) -> list:
    """条目级检索。返回命中的**条目**（不是整块正文），无关时返回空列表。"""
    q = (query or "").strip()
    if not q:
        return []
    st = sync()
    items, mat = st["items"], st["mat"]
    if not items:
        return []

    vec_scores = None
    if mat is not None:
        qv = embed.embed_texts([q], is_query=True)
        if qv is not None and qv.ndim == 2 and qv.shape[1] == mat.shape[1]:
            vec_scores = (mat @ qv[0]).astype(float).tolist()

    qc, qt = _q_sets(q)
    out = []
    for i, it in enumerate(items):
        c, b = _cov_pair(qc, qt, *(_text_sets(it["text"])))
        cov = max(c, b)                       # 门槛：任一说得通就收
        vec = float(vec_scores[i]) if vec_scores else 0.0
        if vec >= min_vec or cov >= min_cov:
            rank_cov = 0.6 * c + 0.4 * b      # 排序：2-gram 更能分近义词边界
            score = (W_VEC * vec + W_COV * rank_cov) if vec_scores else rank_cov
            out.append({
                "level": _label(it, sid),
                "section": it["section"],
                "content": it["text"],
                "source": it["source"],
                "score": round(float(score), 4),
                "vec": round(vec, 4),
                "cov": round(cov, 3),
            })

    out.sort(key=lambda x: x["score"], reverse=True)
    seen, res = set(), []
    for h in out:
        k = h["content"][:80]
        if k in seen:
            continue
        seen.add(k)
        res.append(h)

    # 名额分配：**记忆占前 top_k-1 位，转录固定留 1 个**。
    # 为什么不让两边一起排序：实测查「我在哪个学校读书」时，转录里一段
    # 「帮我做份学校图书馆的PPT」分数 0.478，高于真正的答案
    # 「学校：广州民航职业技术学院…」的 0.375，一起排序会把答案挤出去。
    # 而完全不查转录又会让「我说过什么关于PPT的事」永远看不到历史对话。
    # 分开占名额两头都能顾到。
    n_mem = top_k - 1 if (with_transcripts and top_k > 1) else top_k
    res = res[:n_mem]

    if with_transcripts:
        try:
            for h in _search_transcripts(q, top_k=1):
                k = h["content"][:80]
                if k in seen:
                    continue
                seen.add(k)
                res.append(h)
        except Exception as e:
            _LOG.warning("历史会话检索失败：%s", e)

    return res[:top_k]


def status() -> dict:
    st = sync()
    info = embed.info()
    levels = {}
    for it in st["items"]:
        levels[it["level"]] = levels.get(it["level"], 0) + 1
    d = memory.TRANSCRIPT_DIR
    tfiles, tbytes = 0, 0
    if os.path.isdir(d):
        try:
            for fn in os.listdir(d):
                if fn.endswith(".jsonl"):
                    tfiles += 1
                    tbytes += os.path.getsize(os.path.join(d, fn))
        except Exception:
            logger.debug("silent-except", exc_info=True)
    return {"items": len(st["items"]), "levels": levels,
            "indexed": st["mat"] is not None,
            "backend": info.get("backend", ""), "model": info.get("model", ""),
            "dim": info.get("dim", 0), "ready": bool(info.get("ready")),
            "error": info.get("error", ""),
            "transcript_files": tfiles,
            "transcript_mb": round(tbytes / 1048576.0, 1)}


def rebuild() -> dict:
    """强制全量重建（换模型、或怀疑索引坏了时用）。"""
    with _lock:
        _idx.update({"sig": "", "dsig": "", "items": [], "mat": None})
        _trans.update({"files": {}, "items": []})
        for p in (VEC_FILE, META_FILE):
            try:
                if os.path.isfile(p):
                    os.remove(p)
            except Exception:
                logger.debug("silent-except", exc_info=True)
    t0 = time.time()
    st = sync(force=True)
    info = embed.info()
    return {"items": len(st["items"]), "indexed": st["mat"] is not None,
            "ms": int((time.time() - t0) * 1000),
            "backend": info.get("backend", ""), "model": info.get("model", "")}
